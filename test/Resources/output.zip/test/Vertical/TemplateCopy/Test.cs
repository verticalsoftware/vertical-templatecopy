using System;
using XUnit;

namespace Vertical.TemplateCopy
{
    public sealed class Source 
    {
        // Made by Vertical contributors on 1/1/2020
        
        [Fact]
        public void ThisWorks()
        {
            Assert.True();
        }
    }
}