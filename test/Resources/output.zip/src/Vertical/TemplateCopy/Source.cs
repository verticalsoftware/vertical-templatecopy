using System;

namespace Vertical.TemplateCopy
{
    public sealed class Source 
    {
        // Made by Vertical contributors on 1/1/2020
        
        // TODO: There is no TODO because this is a test file
    }
}