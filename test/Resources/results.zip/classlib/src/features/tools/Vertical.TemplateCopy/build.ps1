# Script created by Vertical contributor

& dotnet build Vertical.TemplateCopy.csproj