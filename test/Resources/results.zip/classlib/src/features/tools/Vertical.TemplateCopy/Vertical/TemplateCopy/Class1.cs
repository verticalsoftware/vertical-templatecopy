using System;

namespace Vertical.TemplateCopy
{
    public class Class1
    {
        // TODO: Enter some code
    }
}
