using System;
using XUnit;

namespace ${Namespace}
{
    public sealed class Source 
    {
        // Made by ${Author} on ${Date}
        
        [Fact]
        public void ThisWorks()
        {
            Assert.True();
        }
    }
}