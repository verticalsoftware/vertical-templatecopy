using System;

namespace ${Namespace}
{
    public sealed class Source 
    {
        // Made by ${Author} on ${Date}
        
        // TODO: There is no TODO because this is a test file
    }
}