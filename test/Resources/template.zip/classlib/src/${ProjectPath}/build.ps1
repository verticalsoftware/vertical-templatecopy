# Script created by ${Author}

& dotnet build ${Project}.csproj