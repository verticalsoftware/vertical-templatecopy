﻿using System;

namespace ${Namespace}
{
    public class Class1
    {
        // TODO: Enter some code
    }
}
