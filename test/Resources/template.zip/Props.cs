using System;
using System.Collections.Generic;

namespace T4Copy
{
    public class Props
    {
        public Props(IDictionary<string, string> properties)
        {
            Namespace = properties["project"];
        }

        public string Author => "Vertical contributors";

        public string Date => "1/1/2020";

        public string Namespace {get;}
    }
}