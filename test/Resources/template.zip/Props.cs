using System;
using System.Collections.Generic;
using Serilog;

namespace T4Copy
{
    public class Props
    {
        public Props(IDictionary<string, string> properties, ILogger logger)
        {
            Namespace = properties["project"];
            logger.Information("Success");
        }

        public string Author => "Vertical contributors";

        public string Date => "1/1/2020";

        public string Namespace {get;}
    }
}